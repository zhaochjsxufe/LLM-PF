from model.bert import bert_ATE
from data.dataset import dataset_ATM
from torch.utils.data import DataLoader
from transformers import BertTokenizer
import torch
from torch.nn.utils.rnn import pad_sequence
import pandas as pd
import time
import numpy as np
from sklearn.metrics import confusion_matrix
from sklearn.metrics import f1_score
import pickle
import os

DEVICE = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
pretrain_model_name = "dr_bert_finetuned2"
tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
lr = 5e-4
model_ATE = bert_ATE(pretrain_model_name).to(DEVICE)
for name, para in model_ATE.named_parameters():
    if 'bert'  in name:
        para.requires_grad = False
optimizer_ATE = torch.optim.Adam(filter(lambda p : p.requires_grad,model_ATE.parameters()), lr=lr)


def evl_time(t):
    min, sec= divmod(t, 60)
    hr, min = divmod(min, 60)
    return int(hr), int(min), int(sec)

def load_model(model, path):
    model.load_state_dict(torch.load(path), strict=False)
    return model

def save_model(model, name):
    torch.save(model.state_dict(), name)

devices_train_ds1 = dataset_ATM(pd.read_csv("data/device/split1/train1.csv"), tokenizer)
devices_train_ds11 = dataset_ATM(pd.read_csv("data/device/split1/train1-2.csv"), tokenizer)
devices_test_ds1 = dataset_ATM(pd.read_csv("data/device/split1/test1.csv"), tokenizer)
devices_train_ds2 = dataset_ATM(pd.read_csv("data/device/split2/train2.csv"), tokenizer)
devices_train_ds22 = dataset_ATM(pd.read_csv("data/device/split2/train2-2.csv"), tokenizer)
devices_test_ds2 = dataset_ATM(pd.read_csv("data/device/split2/test2.csv"), tokenizer)
devices_train_ds3 = dataset_ATM(pd.read_csv("data/device/split3/train3.csv"), tokenizer)
devices_train_ds33 = dataset_ATM(pd.read_csv("data/device/split3/train3-2.csv"), tokenizer)
devices_test_ds3 = dataset_ATM(pd.read_csv("data/device/split3/test3.csv"), tokenizer)
laptops_train_ds1 = dataset_ATM(pd.read_csv("data/laptop/split1/train1.csv"), tokenizer)
laptops_train_ds11 = dataset_ATM(pd.read_csv("data/laptop/split1/train1-2.csv"), tokenizer)
laptops_test_ds1 = dataset_ATM(pd.read_csv("data/laptop/split1/test1.csv"), tokenizer)
laptops_train_ds2 = dataset_ATM(pd.read_csv("data/laptop/split2/train2.csv"), tokenizer)
laptops_train_ds22 = dataset_ATM(pd.read_csv("data/laptop/split2/train2-2.csv"), tokenizer)
laptops_test_ds2 = dataset_ATM(pd.read_csv("data/laptop/split2/test2.csv"), tokenizer)
laptops_train_ds3 = dataset_ATM(pd.read_csv("data/laptop/split3/train3.csv"), tokenizer)
laptops_train_ds33 = dataset_ATM(pd.read_csv("data/laptop/split3/train3-2.csv"), tokenizer)
laptops_test_ds3 = dataset_ATM(pd.read_csv("data/laptop/split3/test3.csv"), tokenizer)
restaurants_train_ds1 = dataset_ATM(pd.read_csv("data/restaurant/split1/train1.csv"), tokenizer)
restaurants_train_ds11 = dataset_ATM(pd.read_csv("data/restaurant/split1/train1-2.csv"), tokenizer)
restaurants_test_ds1 = dataset_ATM(pd.read_csv("data/restaurant/split1/test1.csv"), tokenizer)
restaurants_train_ds2 = dataset_ATM(pd.read_csv("data/restaurant/split2/train2.csv"), tokenizer)
restaurants_train_ds22 = dataset_ATM(pd.read_csv("data/restaurant/split2/train2-2.csv"), tokenizer)
restaurants_test_ds2 = dataset_ATM(pd.read_csv("data/restaurant/split2/test2.csv"), tokenizer)
restaurants_train_ds3 = dataset_ATM(pd.read_csv("data/restaurant/split3/train3.csv"), tokenizer)
restaurants_train_ds33 = dataset_ATM(pd.read_csv("data/restaurant/split3/train3-2.csv"), tokenizer)
restaurants_test_ds3 = dataset_ATM(pd.read_csv("data/restaurant/split3/test3.csv"), tokenizer)

train_ds=restaurants_train_ds1
test_ds=restaurants_test_ds1

def create_mini_batch(samples):
    ids_tensors = [s[1] for s in samples]
    ids_tensors = pad_sequence(ids_tensors, batch_first=True)

    tags_tensors = [s[2] for s in samples]
    tags_tensors = pad_sequence(tags_tensors, batch_first=True)

    pols_tensors = [s[3] for s in samples]
    pols_tensors = pad_sequence(pols_tensors, batch_first=True)
    
    masks_tensors = torch.zeros(ids_tensors.shape, dtype=torch.long)
    masks_tensors = masks_tensors.masked_fill(ids_tensors != 0, 1)
    
    return ids_tensors, tags_tensors, pols_tensors, masks_tensors

train_loader = DataLoader(train_ds, batch_size=16, collate_fn=create_mini_batch, shuffle = True)
test_loader = DataLoader(test_ds, batch_size=16, collate_fn=create_mini_batch, shuffle = True)

def train_model_ATE(loader, epochs):
    best_f1 = 0
    all_data = len(loader)
    for epoch in range(epochs):
        finish_data = 0
        losses = []
        current_times = []
        correct_predictions = 0
        
        for i, data in enumerate(loader):
            t0 = time.time()
            ids_tensors, tags_tensors, _, masks_tensors = data
            ids_tensors = ids_tensors.to(DEVICE)
            tags_tensors = tags_tensors.to(DEVICE)
            masks_tensors = masks_tensors.to(DEVICE)
            loss = model_ATE(ids_tensors=ids_tensors, tags_tensors=tags_tensors, masks_tensors=masks_tensors)
            losses.append(loss.item())
            loss.backward()
            optimizer_ATE.step()
            optimizer_ATE.zero_grad()

            finish_data += 1
            current_times.append(round(time.time()-t0,3))
            current = np.mean(current_times)
            hr, min, sec = evl_time(current*(all_data-finish_data) + current*all_data*(epochs-epoch-1))
            
            print('epoch:', epoch, " batch:", finish_data, "/" , all_data, " loss:", np.mean(losses), " hr:", hr, " min:", min," sec:", sec) 
            
            x, y = test_model_ATE(test_loader)
            f1 = f1_score(x, y, average="macro")
            if f1 > best_f1:
                best_f1 = f1
                best_params = model_ATE.state_dict()
                save_model(model_ATE, 'pkl/r111-2d.pkl')  

def test_model_ATE(loader):
    pred = []
    trueth = []
    with torch.no_grad():
        for data in loader:

            ids_tensors, tags_tensors, _, masks_tensors = data
            ids_tensors = ids_tensors.to(DEVICE)
            tags_tensors = tags_tensors.to(DEVICE)
            masks_tensors = masks_tensors.to(DEVICE)

            outputs = model_ATE(ids_tensors=ids_tensors, tags_tensors=None, masks_tensors=masks_tensors)

            pred += list([int(j) for i in outputs for j in i ])
            trueth += list([int(j) for i in tags_tensors for j in i ])
            
            max_length = max(len(trueth), len(pred))
            pred = pred +[0]* (max_length - len(pred))
            trueth = trueth + [0]* (max_length - len(trueth))

    return trueth, pred

train_model_ATE(train_loader, 15)

model_ATE = load_model(model_ATE, 'pkl/r111-2d.pkl')

x, y = test_model_ATE(test_loader)

print(f1_score(x, y, average='macro'))


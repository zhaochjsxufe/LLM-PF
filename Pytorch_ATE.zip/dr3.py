from model.bert import bert_ATE
from data.dataset import dataset_ATM
from torch.utils.data import DataLoader, ConcatDataset
from transformers import BertTokenizer
import torch
from torch.nn.utils.rnn import pad_sequence
from torch.optim.lr_scheduler import ExponentialLR
from torch.optim.lr_scheduler import StepLR
from torch.optim.lr_scheduler import MultiStepLR
import pandas as pd
import time
import numpy as np
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import f1_score
from sklearn.metrics import accuracy_score
import pickle
import os

DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
pretrain_model_name = 'bert-base-uncased'
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
lr = 7e-4
model_ATE = bert_ATE(pretrain_model_name).to(DEVICE)
model_ATE.load_state_dict(torch.load('pkl/d333.pkl'))
for name, para in model_ATE.named_parameters():
    if 'bert'  in name:
        para.requires_grad = False
optimizer_ATE = torch.optim.Adam(filter(lambda p : p.requires_grad,model_ATE.parameters()), lr=lr)

sheduler = MultiStepLR(optimizer_ATE, milestones=[7,10], gamma=0.8)
#sheduler = ExponentialLR(optimizer_ATE, gamma=0.9)

def evl_time(t):
    min, sec= divmod(t, 60)
    hr, min = divmod(min, 60)
    return int(hr), int(min), int(sec)

def load_model(model, path):
    model.load_state_dict(torch.load(path), strict=False)
    return model

def save_model(model, name):
    torch.save(model.state_dict(), name)

restaurant_train_ds3 = dataset_ATM(pd.read_csv("data/restaurant/split3/train3-2.csv"), tokenizer)
restaurant_test_ds3 = dataset_ATM(pd.read_csv("data/restaurant/split3/test3.csv"), tokenizer)
devices3 = dataset_ATM(pd.read_csv("data/device/split3/dr3.csv"), tokenizer)

def create_mini_batch(samples):
    ids_tensors = [s[1] for s in samples]
    ids_tensors = pad_sequence(ids_tensors, batch_first=True)

    tags_tensors = [s[2] for s in samples]
    tags_tensors = pad_sequence(tags_tensors, batch_first=True)

    pols_tensors = [s[3] for s in samples]
    pols_tensors = pad_sequence(pols_tensors, batch_first=True)
    
    masks_tensors = torch.zeros(ids_tensors.shape, dtype=torch.long)
    masks_tensors = masks_tensors.masked_fill(ids_tensors != 0, 1)
    
    return ids_tensors, tags_tensors, pols_tensors, masks_tensors

train_loader1 = DataLoader(devices3, batch_size=16, collate_fn=create_mini_batch, shuffle = True)
train_loader2 = DataLoader(restaurant_train_ds3, batch_size=16, collate_fn=create_mini_batch, shuffle = True)
test_loader = DataLoader(restaurant_test_ds3, batch_size=16, collate_fn=create_mini_batch, shuffle = True)

save_folder = 'feature/'
load_folder = 'feature/'

for i, data1 in enumerate(train_loader1):
    ids_tensors, tags_tensors, _, masks_tensors = data1
    ids_tensors = ids_tensors.to(DEVICE)
    tags_tensors = tags_tensors.to(DEVICE)
    masks_tensors = masks_tensors.to(DEVICE)
    source_feature_map = model_ATE.get_features(ids_tensors=ids_tensors, tags_tensors=tags_tensors,                                                 masks_tensors=masks_tensors)

    file_path = os.path.join(save_folder, f'dr333_feature_map_{i}.pkl')
    with open(file_path, 'wb') as file:
        pickle.dump(source_feature_map, file)

def train_model_ATE(loader1, loader2, epochs):
    best_f1 = 0
    all_data = len(loader2)
    for epoch in range(epochs):
        finish_data = 0
        losses = []
        losses1 = []
        losses2 =[]
        current_times = []
        correct_predictions = 0
        
        for i, (data1, data2) in enumerate(zip(train_loader1, train_loader2)):
            t0 = time.time()
            ids_tensors, tags_tensors, _, masks_tensors = data2
            ids_tensors = ids_tensors.to(DEVICE)
            tags_tensors = tags_tensors.to(DEVICE)
            masks_tensors = masks_tensors.to(DEVICE)
            
            target_feature_map = model_ATE.get_features(ids_tensors=ids_tensors, tags_tensors=tags_tensors,
                                                 masks_tensors=masks_tensors)
            file_path = os.path.join(save_folder, f'r-d333_feature_map_{i}.pkl')
            with open(file_path, 'wb') as file:
                pickle.dump(target_feature_map, file)
                
                
            loss1 = model_ATE(ids_tensors=ids_tensors, tags_tensors=tags_tensors, masks_tensors=masks_tensors)
            losses1.append(loss1.item())
            
        
            file_path1 = os.path.join(load_folder, f'dr333_feature_map_{i}.pkl')
            with open(file_path1, 'rb') as file:
                source_features = pickle.load(file)
             
            file_path2 = os.path.join(load_folder, f'r-d333_feature_map_{i}.pkl')
            with open(file_path2, 'rb') as file:
                target_features = pickle.load(file)
                
            
            #if source_features.is_cuda:
                #source_features = source_features.detach().cpu().numpy()
            #if target_features.is_cuda:
                #target_features = target_features.detach().cpu().numpy() 
                
            if source_features.shape[1] < target_features.shape[1]:
                target_features = target_features[:, :source_features.shape[1], :]
            else:
                source_features = source_features[:, :target_features.shape[1], :]
            
            #loss2 = np.sum((source_features - target_features)**2)
            #loss2= 0.5*np.sqrt(loss2)
            loss2 = torch.norm(source_features - target_features, p=2, dim=2).mean()
            loss2= 0.5*loss2
            losses2.append(loss2.item())
            
            
            loss = loss1 + 0.8*loss2
            losses.append(loss.item())
            loss.backward()
            optimizer_ATE.step()
            optimizer_ATE.zero_grad()

            finish_data += 1
            current_times.append(round(time.time()-t0,3))
            current = np.mean(current_times)
            hr, min, sec = evl_time(current*(all_data-finish_data) + current*all_data*(epochs-epoch-1))
             
            x, y = test_model_ATE(test_loader)
            f1 = f1_score(x, y, average="macro")
            if f1 > best_f1:
                best_f1 = f1
                best_params = model_ATE.state_dict()
                save_model(model_ATE, 'pkl/dr333.pkl')  
                
            print('epoch:', epoch, " batch:", finish_data, "/" , all_data, " loss:", np.mean(losses), "loss1", np.mean(losses1), "loss2", np.mean(losses2), "f1:", f1, " hr:", hr, " min:", min," sec:", sec)  
        sheduler.step()
    print('best_f1', best_f1)

def test_model_ATE(loader):
    pred = []
    trueth = []
    with torch.no_grad():
        for data in loader:

            ids_tensors, tags_tensors, _, masks_tensors = data
            ids_tensors = ids_tensors.to(DEVICE)
            tags_tensors = tags_tensors.to(DEVICE)
            masks_tensors = masks_tensors.to(DEVICE)

            outputs = model_ATE(ids_tensors=ids_tensors, tags_tensors=None, masks_tensors=masks_tensors)

            pred += list([int(j) for i in outputs for j in i ])
            trueth += list([int(j) for i in tags_tensors for j in i ])
            
            max_length = max(len(trueth), len(pred))
            pred = pred +[0]* (max_length - len(pred))
            trueth = trueth + [0]* (max_length - len(trueth))

    return trueth, pred

train_model_ATE(train_loader1, train_loader2, 15)

model_ATE = load_model(model_ATE, 'pkl/dr333.pkl')

x, y = test_model_ATE(test_loader)
print(f1_score(x, y, average='macro'))
print(accuracy_score(x, y))

from transformers import BertModel
import torch
from torchcrf import CRF

class bert_ATE(torch.nn.Module):
    def __init__(self, pretrain_model,hidden_dim=1024):
        super(bert_ATE, self).__init__()
        self.bert = BertModel.from_pretrained(pretrain_model,return_dict=False)
        self.lstm = torch.nn.LSTM(self.bert.config.hidden_size, hidden_size=hidden_dim//2,
                                  batch_first=True, bidirectional=True)
        self.dropout = torch.nn.Dropout(0.1)
        self.linear = torch.nn.Linear(hidden_dim, 3)
        self.crf = CRF(3,batch_first=True)
        #for param in self.bert.parameters():
            #param.requires_grad = False
        self.loss_fn = torch.nn.CrossEntropyLoss()

    def forward(self, ids_tensors, tags_tensors, masks_tensors):
        bert_outputs,_ = self.bert(input_ids=ids_tensors,  attention_mask=masks_tensors)
        lstm_outputs, _ = self.lstm(bert_outputs)
        lstm_outputs = self.dropout(lstm_outputs)
        linear_outputs = self.linear(lstm_outputs)
        # print(linear_outputs.size())
        
        if tags_tensors is not None:
            tags_tensors = tags_tensors.view(-1)
            linear_outputs = linear_outputs.view(-1,3)
            loss = self.loss_fn(linear_outputs, tags_tensors)
            return loss
        
        else:
            linear_outputs =  self.linear(lstm_outputs)
            decode = self.crf.decode(linear_outputs)
            return decode
        
    def get_features(self, ids_tensors, tags_tensors, masks_tensors):
        with torch.no_grad():
            bert_outputs,_ = self.bert(input_ids=ids_tensors, attention_mask=masks_tensors)
            # print(bert_outputs.size())
            lstm_outputs, _ = self.lstm(bert_outputs)
            lstm_outputs = self.dropout(lstm_outputs)
            features =  self.linear(lstm_outputs)
            return features

